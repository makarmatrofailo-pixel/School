// Расписание уроков и звонков. Время перемены указано после урока.
const schedule = {
  monday: {
    name: 'Понедельник',
    classHour: 'Классный час в 8:30',
    duration: 'Уроки по 40 минут',
    lessons: [
      { subject: 'Зарубежная литература', time: '8:55 — 9:40', break: 10 },
      { subject: 'Физическая культура', time: '9:50 — 10:30', break: 10 },
      { subject: 'Биология', time: '10:40 — 11:20', break: 10 },
      { subject: 'Биология', time: '11:30 — 12:10', break: 20 },
      { subject: 'Английский язык', time: '12:30 — 13:10', break: 10 },
      { subject: 'Английский язык', time: '13:20 — 14:00', break: 15 },
      { subject: 'История Украины', time: '14:15 — 14:55' }
    ]
  },
  tuesday: {
    name: 'Вторник',
    duration: 'Уроки по 45 минут',
    lessons: [
      { subject: 'Испанский / немецкий', time: '8:55 — 9:45', break: 10 },
      { subject: 'Испанский / немецкий', time: '9:55 — 10:40', break: 10 },
      { subject: 'Всемирная история (1 сем.) / ГО (2 сем.)', time: '10:50 — 11:35', break: 10 },
      { subject: 'Физическая культура', time: '11:45 — 12:30', break: 20 },
      { subject: 'Геометрия', time: '12:50 — 13:35', break: 10 },
      { subject: 'Геометрия', time: '13:45 — 14:30', break: 15 },
      { subject: 'Украинский язык', time: '14:45 — 15:30' }
    ]
  },
  wednesday: {
    name: 'Среда',
    duration: 'Уроки по 45 минут',
    lessons: [
      { subject: 'ЗБД', time: '8:55 — 9:45', break: 10 },
      { subject: 'Искусство', time: '9:55 — 10:40', break: 10 },
      { subject: 'Искусство', time: '10:50 — 11:35', break: 10 },
      { subject: 'Технологии', time: '11:45 — 12:30', break: 20 },
      { subject: 'Физическая культура', time: '12:50 — 13:35', break: 10 },
      { subject: 'Физика', time: '13:45 — 14:30', break: 15 },
      { subject: 'Физика', time: '14:45 — 15:30' }
    ]
  },
  thursday: {
    name: 'Четверг',
    duration: 'Уроки по 45 минут',
    lessons: [
      { subject: 'География', time: '8:55 — 9:45', break: 10 },
      { subject: 'География', time: '9:55 — 10:40', break: 10 },
      { subject: 'Алгебра', time: '10:50 — 11:35', break: 10 },
      { subject: 'Алгебра', time: '11:45 — 12:30', break: 20 },
      { subject: 'Украинский язык', time: '12:50 — 13:35', break: 10 },
      { subject: 'Украинский язык', time: '13:45 — 14:30', break: 15 },
      { subject: 'Химия (неделя Б)', time: '14:45 — 15:30' }
    ]
  },
  friday: {
    name: 'Пятница',
    duration: 'Уроки по 45 минут',
    lessons: [
      { subject: 'Английский язык', time: '8:55 — 9:45', break: 10 },
      { subject: 'Английский язык', time: '9:55 — 10:40', break: 10 },
      { subject: 'Информатика', time: '10:50 — 11:35', break: 10 },
      { subject: 'Химия', time: '11:45 — 12:30', break: 20 },
      { subject: 'Алгебра', time: '12:50 — 13:35', break: 10 },
      { subject: 'Украинская литература', time: '13:45 — 14:30', break: 15 },
      { subject: 'Украинская литература', time: '14:45 — 15:30' }
    ]
  }
};
