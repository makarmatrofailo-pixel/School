const menuButton = document.querySelector('.menu-button');
const mobileNav = document.querySelector('#mobile-nav');
const sections = document.querySelectorAll('main > section');
const navigationLinks = document.querySelectorAll('[data-section]');
const dayButtons = document.querySelectorAll('.day-button');
const selectedDay = document.querySelector('#selected-day');
const lessonList = document.querySelector('#lesson-list');
const scheduleDuration = document.querySelector('#schedule-duration');
const classHour = document.querySelector('#class-hour');

function renderSchedule(dayKey) {
  const day = schedule[dayKey];
  selectedDay.textContent = day.name;
  scheduleDuration.textContent = day.duration;
  classHour.textContent = day.classHour || '';
  classHour.hidden = !day.classHour;

  const rows = day.lessons.map((lesson, index) => `
    <div class="lesson-row">
      <span class="lesson-number">${String(index + 1).padStart(2, '0')}</span>
      <div class="lesson-subject"><strong>${lesson.subject}</strong><span>Урок ${index + 1}</span></div>
      <time class="lesson-time">${lesson.time}</time>
      <span class="lesson-break${lesson.break ? '' : ' no-break'}">${lesson.break ? `Перемена ${lesson.break} мин` : 'Конец занятий'}</span>
    </div>
  `).join('');

  lessonList.innerHTML = rows;
  lessonList.setAttribute('aria-label', `Расписание: ${day.name}`);
}

function closeMenu() {
  menuButton.setAttribute('aria-expanded', 'false');
  menuButton.setAttribute('aria-label', 'Открыть меню');
  mobileNav.hidden = true;
}

menuButton.addEventListener('click', () => {
  const isOpen = menuButton.getAttribute('aria-expanded') === 'true';
  menuButton.setAttribute('aria-expanded', String(!isOpen));
  menuButton.setAttribute('aria-label', isOpen ? 'Открыть меню' : 'Закрыть меню');
  mobileNav.hidden = isOpen;
});

mobileNav.addEventListener('click', (event) => {
  if (event.target.closest('a')) closeMenu();
});

document.addEventListener('keydown', (event) => {
  if (event.key === 'Escape') closeMenu();
});

dayButtons.forEach((button) => {
  button.setAttribute('aria-pressed', String(button.classList.contains('active')));

  button.addEventListener('click', () => {
    dayButtons.forEach((item) => {
      item.classList.remove('active');
      item.setAttribute('aria-pressed', 'false');
    });
    button.classList.add('active');
    button.setAttribute('aria-pressed', 'true');
    renderSchedule(button.dataset.day);
  });
});

renderSchedule(document.querySelector('.day-button.active').dataset.day);

const observer = new IntersectionObserver((entries) => {
  const visibleSections = entries
    .filter((entry) => entry.isIntersecting)
    .sort((a, b) => b.intersectionRatio - a.intersectionRatio);

  if (!visibleSections.length) return;
  const currentSection = visibleSections[0].target.id;

  navigationLinks.forEach((link) => {
    const isActive = link.dataset.section === currentSection;
    link.classList.toggle('active', isActive);
    if (isActive) link.setAttribute('aria-current', 'page');
    else link.removeAttribute('aria-current');
  });
}, { rootMargin: '-20% 0px -45% 0px', threshold: [0, 0.2, 0.5] });

sections.forEach((section) => observer.observe(section));
